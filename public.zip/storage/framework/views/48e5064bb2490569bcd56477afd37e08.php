<!DOCTYPE html>
<html lang="">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/remixicon.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/side-menu.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/css-pro-layout.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
    <?php echo $__env->yieldPushContent('extra_css'); ?>
  </head>

  <body>
    <div class="layout has-sidebar fixed-sidebar fixed-header">
      <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div id="overlay" class="overlay"></div>
      <div class="layout">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <div class="overlay"></div>
      </div>
    </div>

    <script src="<?php echo e(asset('js/jquery-3.6.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chart.js')); ?>"></script>
    <script src="<?php echo e(asset('js/side-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html>

<?php /**PATH C:\My Projects\Laravel\shivalik\resources\views/layouts/app.blade.php ENDPATH**/ ?>